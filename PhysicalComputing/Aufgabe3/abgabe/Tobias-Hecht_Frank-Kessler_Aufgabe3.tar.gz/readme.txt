Usage:

to compile type:
make
to execute type:
./aufgabe3 sensordata.txt sensordata.dat
to draw the plot type:
gnuplot tempPlot

